How to run this Library Management System Project

1. Download and Unzip file on your local system copy library.
2. Put library folder inside�root directory

Database Configuration

Open phpmyadmin
Create Database�library
Import database library.sql (available inside zip package)

For User

Open Your browser put inside browser �http://localhost/library�
Login Details for user:�
Username: test@gmail.com
Password: Test@123

For Admin Panel

Open Your browser put inside browser �http://localhost/library/admin�
Login Details for admin :�
Username: admin
Password:Test@123


For More Details --- https://phpgurukul.com/online-library-management-system/